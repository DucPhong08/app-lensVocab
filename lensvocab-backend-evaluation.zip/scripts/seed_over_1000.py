from __future__ import annotations

import asyncio
from datetime import UTC, date, datetime, timedelta
import random
import uuid

from app.bootstrap import setup_beanie
from app.models.flashcard import FlashcardStatus, GlobalFlashcard, UserFlashcard
from app.models.review import ReviewLog, ReviewQuality
from app.models.setting import SystemSetting
from app.models.user import User

# ── 100 Từ vựng mở rộng: Nghề nghiệp, Cảm xúc, Y tế, Học thuật & Khoa học ──
PHASE3_VOCABULARY = [
    # Nghề nghiệp (Jobs & Occupations)
    ("doctor", "/ˈdɒk.tər/", "bác sĩ", "The doctor examined the patient thoroughly.", "She studied ten years to become a pediatrician doctor.", ["physician", "medic", "surgeon"]),
    ("nurse", "/nɜːs/", "y tá, điều dưỡng", "The compassionate nurse administered the prescribed medication.", "Nurses play a critical role in intensive care units.", ["caregiver", "medic", "orderly"]),
    ("teacher", "/ˈtiː.tʃər/", "giáo viên", "An inspiring teacher encourages independent critical thinking.", "The high school teacher graded assignments over the weekend.", ["educator", "instructor", "tutor"]),
    ("engineer", "/ˌen.dʒɪˈnɪər/", "kỹ sư", "Software engineers design robust scalable backend systems.", "The civil engineer inspected the suspension bridge cables.", ["developer", "architect", "technician"]),
    ("chef", "/ʃef/", "đầu bếp trưởng", "The executive chef created an innovative tasting menu.", "The pastry chef decorated the wedding cake with spun sugar.", ["cook", "culinarian", "baker"]),
    ("pilot", "/ˈpaɪ.lət/", "phi công", "The airline pilot navigated smoothly through turbulent clouds.", "Pilots undergo rigorous flight simulator training annually.", ["aviator", "captain", "flyer"]),
    ("lawyer", "/ˈlɔɪ.ər/", "luật sư", "The defense lawyer presented compelling evidence in court.", "Consult an intellectual property lawyer before filing patents.", ["attorney", "counsel", "advocate"]),
    ("architect", "/ˈɑː.kɪ.tekt/", "kiến trúc sư", "The visionary architect designed the green skyscraper.", "Architects draft detailed structural blueprints.", ["designer", "planner", "builder"]),
    ("scientist", "/ˈsaɪən.tɪst/", "nhà khoa học", "Marine scientists study coral bleaching in warming oceans.", "The scientist conducted experiments in the cleanroom.", ["researcher", "scholar", "biologist"]),
    ("journalist", "/ˈdʒɜː.nə.lɪst/", "nhà báo, phóng viên", "The investigative journalist uncovered financial corruption.", "War journalists risk their lives reporting from frontline zones.", ["reporter", "correspondent", "writer"]),
    ("musician", "/mjuːˈzɪʃ.ən/", "nhạc sĩ, nghệ sĩ âm nhạc", "The talented musician composed an orchestral symphony.", "Street musicians performed lively acoustic folk tunes.", ["composer", "instrumentalist", "performer"]),
    ("firefighter", "/ˈfaɪəˌfaɪ.tər/", "lính cứu hỏa", "Courageous firefighters evacuated residents from the building.", "The firefighter donned protective breathing apparatus.", ["rescuer", "fireman", "first responder"]),
    ("police officer", "/pəˈliːs ˌɒf.ɪ.sər/", "cảnh sát viên", "The police officer directed traffic during the power outage.", "Community police officers patrol local school zones daily.", ["cop", "constable", "law enforcer"]),
    ("artist", "/ˈɑː.tɪst/", "họa sĩ, nghệ sĩ", "The contemporary artist exhibited oil paintings downtown.", "She worked diligently in her naturally lit artist studio.", ["painter", "sculptor", "creator"]),
    ("pharmacist", "/ˈfɑː.mə.sɪst/", "dược sĩ", "The licensed pharmacist explained potential medicine interactions.", "Pick up prescribed antibiotic capsules from the pharmacist.", ["chemist", "druggist", "apothecary"]),

    # Cảm xúc & Phẩm chất (Emotions & Traits)
    ("happy", "/ˈhæp.i/", "vui vẻ, hạnh phúc", "The children looked ecstatic and happy on the playground.", "She felt truly happy after passing her entrance exam.", ["cheerful", "joyful", "delighted"]),
    ("confident", "/ˈkɒn.fɪ.dənt/", "tự tin", "A confident speaker engages the entire auditorium audience.", "He felt confident in his technical coding abilities.", ["assured", "poised", "bold"]),
    ("curious", "/ˈkjʊə.ri.əs/", "tò mò, ham học hỏi", "Curious learners ask probing questions during lectures.", "The kitten was curious about the cardboard moving box.", ["inquisitive", "interested", "keen"]),
    ("patient", "/ˈpeɪ.ʃənt/", "kiên nhẫn, nhẫn nại", "A patient tutor explains difficult math concepts step-by-step.", "Practicing meditation teaches you to be more patient.", ["tolerant", "forbearing", "calm"]),
    ("creative", "/kriˈeɪ.tɪv/", "sáng tạo", "Creative thinking solves complex architectural problems.", "She adopted a creative approach to mobile interface design.", ["inventive", "innovative", "original"]),
    ("generous", "/ˈdʒen.ər.əs/", "hào phóng, rộng lượng", "The generous philanthropist donated millions to public schools.", "He gave a generous tip to the courteous restaurant waiter.", ["charitable", "bountiful", "kind"]),
    ("ambitious", "/æmˈbɪʃ.əs/", "có nhiều hoài bão, tham vọng", "Ambitious startup founders aim to disrupt traditional markets.", "She set ambitious targets for her postgraduate research.", ["aspiring", "driven", "determined"]),
    ("grateful", "/ˈɡreɪt.fəl/", "biết ơn", "I am deeply grateful for your generous guidance and advice.", "He felt grateful to have supportive teammates.", ["thankful", "appreciative", "indebted"]),
    ("nervous", "/ˈnɜː.vəs/", "lo lắng, hồi hộp", "Candidates often feel nervous before technical interviews.", "Take deep slow breaths if you feel sudden nervous tension.", ["anxious", "apprehensive", "jittery"]),
    ("brave", "/breɪv/", "dũng cảm", "The brave lifeguard dove into the rough surf to rescue him.", "It was brave of her to voice objections during the meeting.", ["courageous", "valiant", "fearless"]),

    # Sức khỏe & Y tế (Health & Medical)
    ("hospital", "/ˈhɒs.pɪ.təl/", "bệnh viện", "The modern tertiary hospital features advanced MRI scanners.", "Paramedics drove the emergency trauma patient to the hospital.", ["clinic", "infirmary", "medical center"]),
    ("pharmacy", "/ˈfɑː.mə.si/", "hiệu thuốc", "The corner pharmacy stays open twenty-four hours daily.", "Purchase over-the-counter allergy tablets at the pharmacy.", ["drugstore", "chemist", "dispensary"]),
    ("medicine", "/ˈmed.sən/", "thuốc điều trị", "Always finish the full prescribed course of antibiotic medicine.", "Store liquid fever medicine inside a cool dark medicine cabinet.", ["medication", "drug", "remedy"]),
    ("stethoscope", "/ˈsteθ.ə.skəʊp/", "ống nghe y tế", "The doctor placed the cold stethoscope on his chest.", "A quality acoustic stethoscope detects subtle heart murmurs.", ["instrument", "sensor", "tool"]),
    ("thermometer", "/θəˈmɒm.ɪ.tər/", "nhiệt kế", "The infrared ear thermometer showed a slight elevated temperature.", "Use a digital thermometer to check if the child has a fever.", ["gauge", "sensor", "indicator"]),
    ("bandage", "/ˈbæn.dɪdʒ/", "băng gạc", "Wrap an elastic compression bandage around the sprained ankle.", "Apply a clean sterile bandage over the small scrape.", ["dressing", "gauze", "plaster"]),
    ("vitamin", "/ˈvɪt.ə.mɪn/", "vi-ta-min", "Citrus fruits contain high concentrations of vital vitamin C.", "Take a daily multivitamin supplement with your breakfast.", ["nutrient", "supplement", "mineral"]),
    ("fever", "/ˈfiː.vər/", "cơn sốt", "Drink plenty of warm fluids when you have a high fever.", "Her fever dropped significantly after taking paracetamol.", ["temperature", "pyrexia", "illness"]),
    ("headache", "/ˈhed.eɪk/", "đau đầu", "Looking at bright computer monitors all day caused a mild headache.", "Take a short screen break to relieve tension headaches.", ["migraine", "pain", "ache"]),
    ("muscle", "/ˈmʌs.əl/", "cơ bắp", "Regular strength training stimulates healthy muscle hypertrophy.", "Stretch your calf muscles gently after long distance running.", ["tissue", "sinew", "tendon"]),

    # Học thuật & Giáo dục (Academic & Education)
    ("university", "/ˌjuː.nɪˈvɜː.sə.ti/", "trường đại học", "She received an admission offer from a top prestigious university.", "Campus life at the university offers clubs and sports leagues.", ["college", "academy", "institution"]),
    ("library", "/ˈlaɪ.brər.i/", "thư viện", "Students study silently in the university reference library.", "Borrow academic textbooks using your digital library card.", ["archive", "repository", "athenaeum"]),
    ("scholarship", "/ˈskɒl.ə.ʃɪp/", "học bổng", "He won a full merit-based scholarship for overseas studies.", "Apply for international postgraduate research scholarships early.", ["grant", "fellowship", "bursary"]),
    ("laboratory", "/ləˈbɒr.ə.tri/", "phòng thí nghiệm", "Wear protective safety goggles inside the chemistry laboratory.", "The robotics laboratory develops autonomous warehouse rovers.", ["lab", "facility", "workshop"]),
    ("lecture", "/ˈlek.tʃər/", "bài giảng", "The visiting professor delivered a lecture on artificial neural nets.", "Attend morning physics lectures attentively to take notes.", ["talk", "presentation", "address"]),
    ("diploma", "/dɪˈpləʊ.mə/", "văn bằng, chứng chỉ tốt nghiệp", "She framed her bachelor of science diploma on the study wall.", "Present verified copies of your graduation diploma.", ["degree", "certificate", "credential"]),
    ("curriculum", "/kəˈrɪk.jə.ləm/", "chương trình giảng dạy", "The school updated its computer science curriculum to include AI.", "A balanced academic curriculum blends theory with lab practice.", ["syllabus", "coursework", "program"]),
    ("assignment", "/əˈsaɪn.mənt/", "bài tập được giao", "Submit your essay assignment through the online portal before midnight.", "The team collaborated on a joint database design assignment.", ["homework", "task", "project"]),
    ("research", "/rɪˈsɜːtʃ/", "nghiên cứu khoa học", "Extensive empirical research backs this machine learning methodology.", "Conduct thorough literature research before writing your thesis.", ["study", "investigation", "inquiry"]),
    ("semester", "/sɪˈmes.tər/", "học kỳ", "The fall academic semester begins in early September.", "Study hard throughout the sixteen-week college semester.", ["term", "trimester", "period"]),

    # Khoa học & Vũ trụ (Science & Cosmos)
    ("planet", "/ˈplæn.ɪt/", "hành tinh", "Mars is often called the Red Planet due to iron oxide soil.", "Astronomers have discovered thousands of distant exoplanets.", ["celestial body", "world", "orb"]),
    ("galaxy", "/ˈɡæl.ək.si/", "dải ngân hà, thiên hà", "Our solar system resides inside the spiral Milky Way galaxy.", "The James Webb telescope photographed ancient deep-space galaxies.", ["nebula", "cosmos", "star system"]),
    ("telescope", "/ˈtel.ɪ.skəʊp/", "kính viễn vọng, kính thiên văn", "Look through the observatory optical telescope to view Saturn's rings.", "Space telescopes capture ultraviolet light beyond Earth's atmosphere.", ["spyglass", "optics", "instrument"]),
    ("satellite", "/ˈsæt.əl.aɪt/", "vệ tinh nhân tạo", "Communications satellites orbit in geostationary trajectories.", "Weather satellites broadcast real-time storm radar imagery.", ["orbiter", "probe", "spacecraft"]),
    ("gravity", "/ˈɡræv.ə.ti/", "lực hấp dẫn, trọng lực", "Earth's gravity holds our atmosphere securely in place.", "Astronauts experience simulated microgravity aboard the space station.", ["attraction", "gravitation", "pull"]),
    ("energy", "/ˈen.ə.dʒi/", "năng lượng", "Solar and wind infrastructure produce clean renewable energy.", "Conserve electrical energy by turning off unused room appliances.", ["power", "force", "electricity"]),
    ("climate", "/ˈklaɪ.mət/", "khí hậu", "Tropical monsoon climates experience warm wet rainy seasons.", "Global climate change alters seasonal weather cycles.", ["weather", "atmosphere", "environment"]),
    ("oxygen", "/ˈɒk.sɪ.dʒən/", "khí oxy", "Dense green forests generate vital atmospheric oxygen.", "The scuba diver checked his compressed oxygen tank gauge.", ["gas", "air", "breath"]),
    ("experiment", "/ɪkˈsper.ɪ.mənt/", "thí nghiệm", "Record all quantitative test observations during the lab experiment.", "The controlled clinical experiment proved the drug's safety.", ["trial", "test", "investigation"]),
    ("electricity", "/ɪˌlekˈtrɪs.ə.ti/", "điện năng", "Hydropower stations generate abundant green electricity.", "A lightning bolt discharges millions of volts of electricity.", ["power", "current", "voltage"]),
]


async def seed_over_one_thousand() -> dict[str, int]:
    """Bổ sung dữ liệu để tổng số bản ghi trong MongoDB vượt ngưỡng 1.000 bản ghi."""
    await setup_beanie()

    user_email = "user@lensvocab.com"
    admin_email = "admin@lensvocab.com"

    normal_user = await User.find_one({"email": user_email})
    admin_user = await User.find_one({"email": admin_email})

    if not normal_user or not admin_user:
        raise RuntimeError("User accounts not found. Run base seed first.")

    now_utc = datetime.now(UTC)
    today = date.today()

    # ── 1. Thêm 50+ Global Flashcards mới ─────────────────────────────────────
    new_global_cards: list[GlobalFlashcard] = []
    for item in PHASE3_VOCABULARY:
        kw, pron, mean, ex1, ex2, rel = item
        normalized_kw = kw.strip().lower()

        existing = await GlobalFlashcard.find_one({"keyword": normalized_kw})
        if existing is None:
            card = GlobalFlashcard(
                id=uuid.uuid4(),
                keyword=normalized_kw,
                pronunciation=pron,
                meaning_vi=mean,
                example_1=ex1,
                example_2=ex2,
                related_words=rel,
                audio_base64=None,
                embedding=None,
                created_at=now_utc - timedelta(days=random.randint(15, 90)),
            )
            await card.insert()
            new_global_cards.append(card)
        else:
            new_global_cards.append(existing)

    # ── 2. Thêm UserFlashcards (~80-100 bản ghi) ──────────────────────────────
    new_user_cards: list[UserFlashcard] = []
    for idx, gcard in enumerate(new_global_cards):
        existing_uf = await UserFlashcard.find_one({
            "user_id": normal_user.id,
            "global_flashcard_id": gcard.id,
        })
        if existing_uf is not None:
            new_user_cards.append(existing_uf)
            continue

        interval_val = random.randint(1, 35)
        reps = random.randint(1, 6)
        total_rev = reps + random.randint(0, 3)

        uf = UserFlashcard(
            id=uuid.uuid4(),
            user_id=normal_user.id,
            global_flashcard_id=gcard.id,
            status=FlashcardStatus.CONFIRMED if idx % 8 != 0 else FlashcardStatus.DRAFT,
            interval=interval_val,
            repetitions=reps,
            efactor=round(random.uniform(1.8, 2.65), 2),
            next_review_date=today + timedelta(days=random.randint(-1, 20)),
            total_reviews=total_rev,
            added_at=now_utc - timedelta(days=random.randint(10, 60)),
            last_reviewed_at=now_utc - timedelta(days=random.randint(1, 10)),
        )
        await uf.insert()
        new_user_cards.append(uf)

    # ── 3. Bổ sung 250+ ReviewLogs ────────────────────────────────────────────
    review_logs_batch: list[ReviewLog] = []
    for uf in new_user_cards:
        if uf.status != FlashcardStatus.CONFIRMED or uf.total_reviews == 0:
            continue

        num_logs = min(uf.total_reviews, random.randint(2, 5))
        cur_int = 1
        cur_ef = 2.5

        for i in range(num_logs):
            days_ago = max(1, (num_logs - i) * 3 + random.randint(0, 4))
            q_score = random.choice([
                ReviewQuality.CORRECT_HARD,
                ReviewQuality.CORRECT,
                ReviewQuality.PERFECT,
                ReviewQuality.INCORRECT_EASY,
            ]).value

            next_int = max(1, int(cur_int * cur_ef)) if q_score >= 3 else 1
            next_ef = max(1.3, round(cur_ef + (0.1 - (5 - q_score) * (0.08 + (5 - q_score) * 0.02)), 2))

            log = ReviewLog(
                id=uuid.uuid4(),
                user_id=normal_user.id,
                user_flashcard_id=uf.id,
                review_id=uuid.uuid4(),
                quality=q_score,
                interval_before=cur_int,
                interval_after=next_int,
                efactor_before=cur_ef,
                efactor_after=next_ef,
                reviewed_at=now_utc - timedelta(days=days_ago, hours=random.randint(1, 23)),
            )
            review_logs_batch.append(log)
            cur_int = next_int
            cur_ef = next_ef

    if review_logs_batch:
        await ReviewLog.insert_many(review_logs_batch)

    stats = {
        "users": await User.count(),
        "global_flashcards": await GlobalFlashcard.count(),
        "user_flashcards": await UserFlashcard.count(),
        "review_logs": await ReviewLog.count(),
        "system_settings": await SystemSetting.count(),
    }
    stats["total"] = sum(stats.values())
    return stats


if __name__ == "__main__":
    res = asyncio.run(seed_over_one_thousand())
    print("\n" + "=" * 55)
    print("🔥 SEED DỮ LIỆU VƯỢT 1.000 BẢN GHI THÀNH CÔNG!")
    print("=" * 55)
    for k, v in res.items():
        if k != "total":
            print(f"  - {k:<20}: {v:>5} bản ghi")
    print("-" * 55)
    print(f"  ⭐ TỔNG SỐ BẢN GHI TOÀN BỘ HỆ THỐNG: {res['total']:>5} bản ghi")
    print("=" * 55)
