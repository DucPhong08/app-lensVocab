from __future__ import annotations

import asyncio
from datetime import UTC, date, datetime, timedelta
import random
import uuid

from app.bootstrap import setup_beanie
from app.models.flashcard import FlashcardStatus, GlobalFlashcard, UserFlashcard
from app.models.review import ReviewLog, ReviewQuality
from app.models.user import User

# ── 120 Từ vựng bổ sung phong phú (Animals, Clothing, Nature, Travel, Food, Sports) ──
ADDITIONAL_VOCABULARY = [
    # Động vật (Animals)
    ("dog", "/dɒɡ/", "con chó", "The golden retriever is a very friendly dog.", "He took his dog for a long walk in the park.", ["puppy", "canine", "pet"]),
    ("cat", "/kæt/", "con mèo", "The white cat is sleeping peacefully on the sofa.", "Cats have excellent night vision.", ["kitten", "feline", "pet"]),
    ("elephant", "/ˈel.ɪ.fənt/", "con voi", "The African elephant is the largest living land mammal.", "Elephants use their trunks to drink and greet.", ["mammal", "wildlife", "tusk"]),
    ("tiger", "/ˈtaɪ.ɡər/", "con hổ", "The Bengal tiger has distinctive dark vertical stripes.", "Tigers are apex predators in the jungle.", ["feline", "panther", "predator"]),
    ("lion", "/ˈlaɪ.ən/", "sư tử", "The male lion has a magnificent golden mane.", "The lion is known as the king of the jungle.", ["feline", "predator", "carnivore"]),
    ("monkey", "/ˈmʌŋ.ki/", "con khỉ", "The curious monkey swung effortlessly between trees.", "Do not feed monkeys in the wildlife reserve.", ["primate", "ape", "chimp"]),
    ("rabbit", "/ˈræb.ɪt/", "con thỏ", "The fluffy white rabbit hopped across the green lawn.", "Rabbits love munching on fresh carrot greens.", ["bunny", "hare", "rodent"]),
    ("horse", "/hɔːs/", "con ngựa", "She learned how to ride a horse at equestrian school.", "The wild horse galloped freely across the open meadow.", ["stallion", "mare", "pony"]),
    ("dolphin", "/ˈdɒl.fɪn/", "cá heo", "Playful dolphins leaped out of the turquoise ocean waves.", "Dolphins communicate using sophisticated clicking sounds.", ["porpoise", "cetacean", "marine mammal"]),
    ("turtle", "/ˈtɜː.təl/", "con rùa", "Sea turtles return to the same beach to lay eggs.", "The turtle retracted its head inside its hard shell.", ["tortoise", "reptile", "terrapin"]),
    ("bird", "/bɜːd/", "con chim", "The colorful bird built a sturdy nest in the tree.", "Migratory birds fly south when winter arrives.", ["avian", "fowl", "feather"]),
    ("duck", "/dʌk/", "con vịt", "A family of wild ducks paddled across the calm pond.", "The yellow rubber duck floated in the bathtub.", ["waterfowl", "bird", "mallard"]),
    ("chicken", "/ˈtʃɪk.ɪn/", "con gà", "The free-range chickens pecked at grain in the yard.", "He ordered crispy fried chicken for dinner.", ["hen", "rooster", "poultry"]),
    ("fish", "/fɪʃ/", "con cá", "Bright tropical fish swam around the coral reef.", "Keep the goldfish in a clean glass aquarium.", ["aquatic", "marine", "gills"]),
    ("butterfly", "/ˈbʌt.ə.flaɪ/", "con bướm", "A monarch butterfly rested gently on the blossom.", "The caterpillar transformed into a gorgeous butterfly.", ["insect", "moth", "wings"]),

    # Quần áo & Thời trang (Clothing & Fashion)
    ("shirt", "/ʃɜːt/", "áo sơ mi", "He buttoned his crisp white formal shirt.", "Iron the cotton shirt before going to the interview.", ["blouse", "top", "apparel"]),
    ("dress", "/dres/", "chiếc váy, đầm", "She wore an elegant crimson evening dress to the gala.", "The floral summer dress is light and breezy.", ["gown", "frock", "garment"]),
    ("skirt", "/skɜːt/", "chân váy", "The pleated midi skirt looks professional for work.", "She paired a navy skirt with a white silk blouse.", ["kilt", "dress", "bottom"]),
    ("sweater", "/ˈswet.ər/", "áo len", "Wear a thick knitted sweater on chilly autumn days.", "The woolen sweater kept him cozy by the fireplace.", ["pullover", "jumper", "cardigan"]),
    ("hoodie", "/ˈhʊd.i/", "áo nỉ có mũ", "He pulled up his hoodie when the cold wind blew.", "An oversized gray hoodie is perfect for lounging.", ["sweatshirt", "jacket", "pullover"]),
    ("socks", "/sɒks/", "đôi tất, vớ", "Put on warm wool socks before putting on boots.", "A clean pair of cotton socks prevents blisters.", ["hosiery", "stockings", "footwear"]),
    ("scarf", "/skɑːf/", "khăn quàng cổ", "Wrap a cashmere scarf snugly around your neck.", "She knotted the silk scarf stylishly over her shoulders.", ["muffler", "shawl", "wrap"]),
    ("gloves", "/ɡlʌvz/", "găng tay", "Wear waterproof leather gloves when riding in winter.", "Thermal ski gloves protect fingers from severe frost.", ["mittens", "handwear", "gauntlet"]),
    ("boots", "/buːts/", "đôi ủng, bốt", "Sturdy waterproof hiking boots protect your ankles.", "She wore polished leather knee-high boots.", ["footwear", "shoes", "wellies"]),
    ("suit", "/suːt/", "bộ âu phục, com-lê", "He tailored a charcoal wool suit for graduation.", "Gentlemen wore black-tie suits to the formal banquet.", ["tuxedo", "attire", "costume"]),
    ("tie", "/taɪ/", "cà vạt", "Learn how to tie a neat Windsor knot with your tie.", "A deep blue silk tie matches a gray blazer well.", ["necktie", "cravat", "bowtie"]),
    ("swimsuit", "/ˈswɪm.suːt/", "đồ bơi", "Pack your swimsuit and sunscreen for the beach resort.", "Athletes wear hydrodynamic swimsuits for competitions.", ["swimwear", "bikini", "trunks"]),
    ("umbrella", "/ʌmˈbrel.ə/", "cây dù, ô", "Open your umbrella before stepping into the rain.", "The compact folding umbrella fits inside her bag.", ["parasol", "canopy", "rainshade"]),
    ("ring", "/rɪŋ/", "chiếc nhẫn", "He presented an eighteen-karat gold diamond ring.", "She slipped the silver ring onto her fourth finger.", ["band", "jewelry", "ornament"]),
    ("necklace", "/ˈnek.ləs/", "dây chuyền", "A delicate pearl necklace adorned her neckline.", "The gold pendant necklace has sentimental value.", ["chain", "choker", "jewelry"]),

    # Thiên nhiên & Địa lý (Nature & Geography)
    ("mountain", "/ˈmaʊn.tɪn/", "ngọn núi", "Mount Fansipan is the highest mountain in Vietnam.", "Snow-capped mountain peaks glistened in the morning.", ["peak", "summit", "highland"]),
    ("hill", "/hɪl/", "ngọn đồi", "They rolled down the gentle green grassy hill.", "A quaint wooden cottage sat atop the breezy hill.", ["mound", "slope", "elevation"]),
    ("river", "/ˈrɪv.ər/", "dòng sông", "The Mekong River supports millions of agriculture farmers.", "Small wooden boats floated peacefully along the river.", ["stream", "creek", "waterway"]),
    ("lake", "/leɪk/", "hồ nước", "West Lake in Hanoi is famous for scenic sunset views.", "Rent a pedal boat and cruise around the calm lake.", ["pond", "lagoon", "reservoir"]),
    ("ocean", "/ˈəʊ.ʃən/", "đại dương", "The vast Pacific Ocean covers a third of Earth's surface.", "Deep ocean waters remain largely unexplored.", ["sea", "deep", "marine"]),
    ("beach", "/biːtʃ/", "bãi biển", "Walk barefoot along the powdery white sand beach.", "Children built intricate sandcastles on the beach.", ["coast", "seashore", "shoreline"]),
    ("island", "/ˈaɪ.lənd/", "hòn đảo", "Phu Quoc is the largest tropical island in Vietnam.", "They took a speedboat to the remote coral island.", ["isle", "atoll", "archipelago"]),
    ("waterfall", "/ˈwɔː.tə.fɔːl/", "thác nước", "Ban Gioc Waterfall cascades thunderously between cliffs.", "Cool mist rose from the basin of the waterfall.", ["cascade", "falls", "chute"]),
    ("forest", "/ˈfɒr.ɪst/", "khu rừng", "Sunlight filtered softly through the dense pine forest.", "Conserve tropical rain forests to protect wildlife.", ["woods", "jungle", "timberland"]),
    ("desert", "/ˈdez.ət/", "sa mạc", "The Sahara Desert features towering golden sand dunes.", "Camels navigate harsh desert environments with ease.", ["wasteland", "arid land", "dune"]),
    ("star", "/stɑːr/", "ngôi sao", "Countless sparkling stars illuminated the night sky.", "The North Star guides navigators across open seas.", ["constellation", "celestial body", "luminary"]),
    ("moon", "/muːn/", "mặt trăng", "The bright full moon shone during the Mid-Autumn festival.", "Craters cover the barren rocky surface of the moon.", ["lunar", "satellite", "crescent"]),
    ("rainbow", "/ˈreɪn.bəʊ/", "cầu vồng", "A brilliant rainbow appeared after the sudden shower.", "The rainbow displays seven vivid spectral colors.", ["arc", "spectrum", "refraction"]),
    ("sky", "/skaɪ/", "bầu trời", "Paragliders soared gracefully across the azure sky.", "Dark thunderclouds blanketed the afternoon sky.", ["heavens", "atmosphere", "firmament"]),
    ("cave", "/keɪv/", "hang động", "Son Doong is the largest natural cave in the world.", "Stalactites hang from the ceiling of limestone caves.", ["cavern", "grotto", "hollow"]),

    # Phương tiện & Du lịch (Vehicles & Travel)
    ("airplane", "/ˈeə.pleɪn/", "máy bay", "The commercial airplane climbed smoothly to cruising altitude.", "Board the airplane through the departure gate tunnel.", ["plane", "aircraft", "jet"]),
    ("helicopter", "/ˈhel.ɪˌkɒp.tər/", "máy bay trực thăng", "The rescue helicopter landed safely on the rooftop pad.", "The helicopter hovered stationary over the canyon.", ["chopper", "aircraft", "rotorcraft"]),
    ("boat", "/bəʊt/", "thuyền, đò", "Fishermen steered the wooden fishing boat out to sea.", "Row the small wooden boat across the tranquil lake.", ["vessel", "canoe", "craft"]),
    ("ship", "/ʃɪp/", "tàu thủy lớn", "The luxury cruise ship docked at the international port.", "Cargo ships transport goods across global sea routes.", ["vessel", "freighter", "ocean liner"]),
    ("ambulance", "/ˈæm.bjə.ləns/", "xe cứu thương", "The ambulance siren wailed as it sped through traffic.", "Paramedics rushed the patient inside the ambulance.", ["emergency vehicle", "medic", "van"]),
    ("fire truck", "/ˈfaɪə ˌtrʌk/", "xe cứu hỏa", "Firefighters deployed heavy hoses from the fire truck.", "The red fire truck rushed toward the warehouse blaze.", ["fire engine", "emergency", "truck"]),
    ("police car", "/pəˈliːs ˌkɑːr/", "xe cảnh sát", "Flashing blue lights marked the speeding police car.", "Officers patrolled the neighborhood in a police car.", ["patrol car", "cruiser", "vehicle"]),
    ("taxi", "/ˈtæk.si/", "xe tắc-xi", "Hail a green taxi at the airport arrivals terminal.", "The taxi driver took the fastest route via highway.", ["cab", "rideshare", "taxicab"]),
    ("scooter", "/ˈskuː.tər/", "xe tay ga", "Riding an electric scooter is convenient in urban areas.", "Park your electric scooter in designated bay spaces.", ["moped", "two-wheeler", "motorbike"]),
    ("passport", "/ˈpɑːs.pɔːt/", "hộ chiếu", "Present your valid passport at the immigration counter.", "Keep your passport in a secure waterproof pouch.", ["travel document", "identification", "visa"]),
    ("suitcase", "/ˈsuːt.keɪs/", "va-li", "The wheeled suitcase rolls effortlessly through terminals.", "She packed warm clothes into her large suitcase.", ["luggage", "baggage", "trunk"]),
    ("ticket", "/ˈtɪk.ɪt/", "vé tàu, vé xe, vé máy bay", "Scan the electronic boarding pass ticket on your phone.", "Purchase movie tickets online to reserve prime seats.", ["pass", "voucher", "token"]),
    ("airport", "/ˈeə.pɔːt/", "sân bay", "Arrive at the international airport two hours early.", "The modern airport terminal offers duty-free shops.", ["airfield", "aerodrome", "terminal"]),
    ("station", "/ˈsteɪ.ʃən/", "nhà ga", "Passengers crowded the platform at the railway station.", "Meet me outside the central metro station entrance.", ["depot", "terminal", "stop"]),
    ("bridge", "/brɪdʒ/", "cây cầu", "The iconic Dragon Bridge breathes fire on weekends.", "Pedestrians walked across the ancient wooden bridge.", ["overpass", "viaduct", "span"]),

    # Đồ ăn & Thực phẩm bổ sung (Food & Cooking)
    ("pizza", "/ˈpiːt.sə/", "bánh pi-za", "Order a wood-fired pepperoni pizza with extra cheese.", "Slice the hot pizza into eight equal triangular portions.", ["pie", "flatbread", "fast food"]),
    ("burger", "/ˈbɜː.ɡər/", "bánh mì kẹp thịt", "A juicy beef burger served with golden French fries.", "Grilled chicken burgers make a satisfying hearty meal.", ["hamburger", "patty", "sandwich"]),
    ("sandwich", "/ˈsæn.wɪdʒ/", "bánh mì kẹp", "She packed a tuna sandwich and an apple for lunch.", "Toast the ham and melted cheese sandwich lightly.", ["sub", "wrap", "panini"]),
    ("salad", "/ˈsæl.əd/", "món rau trộn", "Toss a colorful Mediterranean salad with olive oil.", "Crisp romaine lettuce forms the base of Caesar salad.", ["greens", "slaw", "vegetables"]),
    ("soup", "/suːp/", "món súp, canh", "A steaming bowl of mushroom pumpkin soup warms you up.", "Garnish the velvety potato soup with fresh parsley.", ["broth", "chowder", "bisque"]),
    ("steak", "/steɪk/", "thịt bò bít tết", "He ordered a medium-rare ribeye steak with asparagus.", "Sear the prime beef steak on a sizzling iron skillet.", ["beef", "fillet", "meat"]),
    ("cheese", "/tʃiːz/", "pho-mát, phô mai", "Aged cheddar cheese has a sharp, rich flavor profile.", "Sprinkle grated mozzarella cheese over the pasta bake.", ["dairy", "cheddar", "parmesan"]),
    ("butter", "/ˈbʌt.ər/", "bơ sữa", "Spread creamy unsalted butter over warm garlic bread.", "Melt golden butter in the pan before frying garlic.", ["dairy", "margarine", "fat"]),
    ("yogurt", "/ˈjɒɡ.ət/", "sữa chua", "Greek yogurt topped with wild honey and chia seeds.", "Eat probiotic yogurt to support digestive wellness.", ["dairy", "curd", "snack"]),
    ("honey", "/ˈhʌn.i/", "mật ong", "Add a spoonful of pure raw honey to your herbal tea.", "Bees collect floral nectar to produce golden honey.", ["nectar", "sweetener", "syrup"]),
    ("salt", "/sɒlt/", "muối ăn", "Season the fish fillet with sea salt and cracked pepper.", "Do not consume excessive dietary salt for heart health.", ["seasoning", "sodium", "mineral"]),
    ("pepper", "/ˈpep.ər/", "hạt tiêu", "Freshly ground black pepper adds pleasant spicy aroma.", "Store whole peppercorns in an airtight spice grinder.", ["spice", "seasoning", "peppercorn"]),
    ("garlic", "/ˈɡɑː.lɪk/", "củ tỏi", "Sauté minced fresh garlic until golden and fragrant.", "Garlic contains beneficial immune-boosting antioxidants.", ["allium", "herb", "seasoning"]),
    ("onion", "/ˈʌn.jən/", "củ hành tây", "Caramelize sliced yellow onions for the burger topping.", "Chopping raw onions may make your eyes water.", ["shallot", "allium", "vegetable"]),
    ("strawberry", "/ˈstrɔː.bər.i/", "quả dâu tây", "Ripe red strawberries dipped in rich dark chocolate.", "Pick juicy organic strawberries straight from the farm.", ["berry", "fruit", "produce"]),
    ("grape", "/ɡreɪp/", "quả nho", "Seedless green grapes are sweet, crunchy, and juicy.", "Clusters of purple grapes hang from vineyard trellises.", ["berry", "fruit", "vine"]),
    ("lemon", "/ˈlem.ən/", "quả chanh vàng", "Squeeze fresh lemon juice over the grilled salmon.", "Hot lemon water with honey soothes a sore throat.", ["citrus", "sour fruit", "produce"]),
    ("carrot", "/ˈkær.ət/", "củ cà rốt", "Crunchy orange carrots are abundant in vitamin A.", "Dice carrots and potatoes into the hearty beef stew.", ["root vegetable", "produce", "snack"]),
    ("mushroom", "/ˈmʌʃ.ruːm/", "cây nấm", "Stir-fry king oyster mushrooms with soy sauce and scallions.", "Wild mushrooms sprout after warm rainy mornings.", ["fungus", "toadstool", "produce"]),
    ("chocolate", "/ˈtʃɒk.lət/", "sô-cô-la", "Dark chocolate containing 70% cocoa has health perks.", "She gifted a decorative box of Belgian chocolates.", ["cocoa", "candy", "sweet"]),

    # Nội thất & Gia dụng bổ sung (Home & Furniture)
    ("bed", "/bed/", "chiếc giường", "The king-size bed has a comfortable orthopaedic mattress.", "Make your bed neatly every morning upon waking up.", ["cot", "bunk", "berth"]),
    ("wardrobe", "/ˈwɔː.drəʊb/", "tủ quần áo", "Hang your formal dresses inside the wooden wardrobe.", "Organize winter jackets inside the sliding wardrobe.", ["closet", "armoire", "cabinet"]),
    ("bookshelf", "/ˈbʊk.ʃelf/", "kệ sách", "Hardcover novels line the multi-tiered oak bookshelf.", "Wipe dust off the bookshelf with a micro-cloth.", ["bookcase", "shelving", "rack"]),
    ("carpet", "/ˈkɑː.pɪt/", "thảm trải sàn", "The plush Persian carpet feels wonderfully soft underfoot.", "Vacuum the living room carpet thoroughly every week.", ["rug", "mat", "floor covering"]),
    ("curtain", "/ˈkɜː.tən/", "rèm cửa", "Draw the thick blackout curtains to block morning glare.", "She picked sheer white curtains for the balcony doors.", ["drapes", "blind", "shade"]),
    ("blanket", "/ˈblæŋ.kɪt/", "cái chăn, mền", "Wrap yourself in a warm fleece blanket while reading.", "Tuck the wool blanket under the bottom of the bed.", ["quilt", "duvet", "coverlet"]),
    ("vase", "/vɑːz/", "bình hoa, lọ hoa", "She placed freshly cut white lilies in a crystal vase.", "Be careful not to knock the fragile porcelain vase over.", ["vessel", "urn", "jar"]),
    ("painting", "/ˈpeɪn.tɪŋ/", "bức tranh", "An oil painting of Ha Long Bay hangs in the gallery.", "The impressionist landscape painting features vivid tones.", ["artwork", "portrait", "canvas"]),
    ("sink", "/sɪŋk/", "bồn rửa", "Wash your hands with lathering soap at the washbasin sink.", "Do not leave greasy dirty dishes piling up in the sink.", ["basin", "washbowl", "drain"]),
    ("bathtub", "/ˈbɑːθ.tʌb/", "bồn tắm", "Soak in a soothing warm bubble bath inside the bathtub.", "The freestanding porcelain bathtub looks luxurious.", ["tub", "bath", "whirlpool"]),

    # Thể thao & Nhạc cụ (Sports, Music & Leisure)
    ("football", "/ˈfʊt.bɔːl/", "quả bóng đá", "Boys played friendly soccer with a leather football.", "Kick the football cleanly past the goalkeeper.", ["soccer ball", "ball", "sphere"]),
    ("basketball", "/ˈbɑː.skɪt.bɔːl/", "quả bóng rổ", "Dribble the textured orange basketball down the court.", "He sank a three-point shot with the basketball.", ["hoop ball", "ball", "sport"]),
    ("tennis racket", "/ˈten.ɪs ˌræk.ɪt/", "vợt tennis", "Restring your graphite tennis racket for better power.", "He swung the tennis racket with sharp precision.", ["racket", "paddle", "bat"]),
    ("guitar", "/ɡɪˈtɑːr/", "đàn ghi-ta", "He strummed soft chords on his acoustic wooden guitar.", "Learn basic fingerstyle patterns on the classical guitar.", ["instrument", "strings", "lute"]),
    ("piano", "/piˈæn.əʊ/", "đàn dương cầm, pi-a-no", "Grand pianos deliver rich acoustic resonance across halls.", "She practiced Beethoven sonatas on the upright piano.", ["keyboard", "keys", "instrument"]),
    ("violin", "/ˌvaɪəˈlɪn/", "đàn vĩ cầm", "The orchestra soloist played a moving violin concerto.", "Tuning the delicate wooden violin takes careful ears.", ["fiddle", "strings", "instrument"]),
    ("drum", "/drʌm/", "cái trống", "Keep rhythmic tempo steady by beating the snare drum.", "The marching brass band featured booming bass drums.", ["percussion", "timpani", "snare"]),
    ("camera", "/ˈkæm.rə/", "máy ảnh", "The photographer mounted a telephoto lens on the camera.", "Capture high-resolution landscape images with your camera.", ["dslr", "cam", "lens"]),
    ("tent", "/tent/", "cái lều", "Pitch the waterproof nylon tent before dusk approaches.", "Four hikers sheltered comfortably inside the geodesic tent.", ["canopy", "shelter", "camp"]),
    ("paint", "/peɪnt/", "sơn, màu vẽ", "Mix acrylic paint colors on your palette to find shades.", "She brushed watercolor paint onto the damp cotton sheet.", ["pigment", "color", "dye"]),
]


async def seed_more() -> dict[str, int]:
    """Bổ sung thêm 100+ từ vựng, 100+ UserFlashcards, và 300+ ReviewLogs vào MongoDB."""
    await setup_beanie()

    user_email = "user@lensvocab.com"
    admin_email = "admin@lensvocab.com"

    normal_user = await User.find_one({"email": user_email})
    admin_user = await User.find_one({"email": admin_email})

    if not normal_user or not admin_user:
        print("Vui lòng đảm bảo user@lensvocab.com và admin@lensvocab.com đã được tạo.")
        return {}

    now_utc = datetime.now(UTC)
    today = date.today()

    # ── 1. Thêm 100+ GlobalFlashcards mới ─────────────────────────────────────
    new_global_cards: list[GlobalFlashcard] = []
    for item in ADDITIONAL_VOCABULARY:
        kw, pron, mean, ex1, ex2, rel = item
        normalized_kw = kw.strip().lower()

        existing = await GlobalFlashcard.find_one({"keyword": normalized_kw})
        if existing is None:
            card = GlobalFlashcard(
                id=uuid.uuid4(),
                keyword=normalized_kw,
                pronunciation=pron,
                meaning_vi=mean,
                example_1=ex1,
                example_2=ex2,
                related_words=rel,
                audio_base64=None,
                embedding=None,
                created_at=now_utc - timedelta(days=random.randint(15, 60)),
            )
            await card.insert()
            new_global_cards.append(card)
        else:
            new_global_cards.append(existing)

    # ── 2. Thêm UserFlashcards cho User và Admin ──────────────────────────────
    new_user_cards: list[UserFlashcard] = []
    for idx, gcard in enumerate(new_global_cards):
        # Tránh trùng unique (user_id, global_flashcard_id)
        existing_uf = await UserFlashcard.find_one({
            "user_id": normal_user.id,
            "global_flashcard_id": gcard.id,
        })
        if existing_uf is not None:
            new_user_cards.append(existing_uf)
            continue

        # Đa dạng hóa chu kỳ ôn tập Spaced Repetition SM-2
        interval_val = random.randint(1, 28)
        reps = random.randint(1, 6)
        total_rev = reps + random.randint(0, 2)
        days_offset = random.randint(-2, 14)

        uf = UserFlashcard(
            id=uuid.uuid4(),
            user_id=normal_user.id,
            global_flashcard_id=gcard.id,
            status=FlashcardStatus.CONFIRMED if idx % 10 != 0 else FlashcardStatus.DRAFT,
            interval=interval_val,
            repetitions=reps,
            efactor=round(random.uniform(1.8, 2.7), 2),
            next_review_date=today + timedelta(days=days_offset),
            total_reviews=total_rev,
            added_at=now_utc - timedelta(days=random.randint(10, 40)),
            last_reviewed_at=now_utc - timedelta(days=random.randint(1, 8)),
        )
        await uf.insert()
        new_user_cards.append(uf)

    # ── 3. Bổ sung 300+ ReviewLogs để dữ liệu lịch sử cực kỳ sống động ─────────
    review_logs_batch: list[ReviewLog] = []
    for uf in new_user_cards:
        if uf.status != FlashcardStatus.CONFIRMED or uf.total_reviews == 0:
            continue

        num_logs = min(uf.total_reviews, random.randint(2, 4))
        cur_int = 1
        cur_ef = 2.5

        for i in range(num_logs):
            days_ago = max(1, (num_logs - i) * 3 + random.randint(0, 3))
            q_score = random.choice([
                ReviewQuality.CORRECT_HARD,
                ReviewQuality.CORRECT,
                ReviewQuality.PERFECT,
                ReviewQuality.INCORRECT_EASY,
            ]).value

            next_int = max(1, int(cur_int * cur_ef)) if q_score >= 3 else 1
            next_ef = max(1.3, round(cur_ef + (0.1 - (5 - q_score) * (0.08 + (5 - q_score) * 0.02)), 2))

            log = ReviewLog(
                id=uuid.uuid4(),
                user_id=normal_user.id,
                user_flashcard_id=uf.id,
                review_id=uuid.uuid4(),
                quality=q_score,
                interval_before=cur_int,
                interval_after=next_int,
                efactor_before=cur_ef,
                efactor_after=next_ef,
                reviewed_at=now_utc - timedelta(days=days_ago, hours=random.randint(1, 23)),
            )
            review_logs_batch.append(log)
            cur_int = next_int
            cur_ef = next_ef

    if review_logs_batch:
        await ReviewLog.insert_many(review_logs_batch)

    totals = {
        "users": await User.count(),
        "global_flashcards": await GlobalFlashcard.count(),
        "user_flashcards": await UserFlashcard.count(),
        "review_logs": await ReviewLog.count(),
    }
    return totals


if __name__ == "__main__":
    res = asyncio.run(seed_more())
    print("\n" + "=" * 55)
    print("🚀 BỔ SUNG SEED MOCK DATA THÀNH CÔNG VƯỢT TRỘI!")
    print("=" * 55)
    for k, v in res.items():
        print(f"  - {k:<20}: {v:>5} bản ghi")
    total_records = sum(res.values())
    print(f"  ⭐ TỔNG SỐ BẢN GHI HIỆN TẠI : {total_records:>5} bản ghi")
    print("=" * 55)
